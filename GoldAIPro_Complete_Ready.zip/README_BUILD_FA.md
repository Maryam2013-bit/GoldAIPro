# Gold AI Pro Android

این پروژه یک Android App واقعی با Gradle + Kotlin + Jetpack Compose است.

## ساخت APK
روی کامپیوتری که Android Studio و Android SDK دارد:
1. پروژه را با Android Studio باز کنید.
2. Gradle Sync را اجرا کنید.
3. `Build > Build APK(s)` را بزنید.
4. APK در `app/build/outputs/apk/` قرار می‌گیرد.

## نکته
رابط، دکمه بروزرسانی، تب‌ها و ساختار اپ واقعی هستند؛ اما داده بازار تا اتصال Backend و منابع واقعی، عمداً شبیه‌سازی نمی‌شود.
