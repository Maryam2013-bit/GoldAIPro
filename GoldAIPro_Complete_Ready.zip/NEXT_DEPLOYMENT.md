# مرحله استقرار واقعی
1. تعیین InsCode/ISIN دقیق صندوق عیار در محیط استقرار.
2. اتصال Adapter به منبع داده قابل اتکا و مجاز.
3. راه‌اندازی سرور HTTPS.
4. دیتابیس تاریخچه و صف رویداد.
5. تست endpointها و کنترل freshness.
6. اتصال Android به API.
7. Build با Android SDK/Gradle و امضای APK.

TSETMC endpoints برای قیمت، order book، حقیقی/حقوقی و ETF مستند شده‌اند؛ با این حال برخی endpointهای CDN غیررسمی هستند و ممکن است تغییر کنند، بنابراین Adapter قابل تعویض باقی مانده است.
