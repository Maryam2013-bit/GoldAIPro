
from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass
class DataQuality:
    ok: bool
    age_seconds: float | None
    reason: str

def assess(timestamp: datetime | None, max_age: int = 30) -> DataQuality:
    if timestamp is None:
        return DataQuality(False, None, "timestamp_missing")
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    age = max(0.0, (datetime.now(timezone.utc)-timestamp).total_seconds())
    return DataQuality(age <= max_age, age, "fresh" if age <= max_age else "stale")
