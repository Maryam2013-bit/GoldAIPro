
def build_alerts(snapshot: dict, previous: dict | None = None):
    alerts=[]
    if snapshot.get("data_stale"):
        alerts.append({"type":"DATA","severity":"high","text":"داده قدیمی است؛ سیگنال لحظه‌ای صادر نمی‌شود."})
        return alerts
    if snapshot.get("reversal_probability",0) >= 70:
        alerts.append({"type":"REVERSAL","severity":"high","text":"احتمال تغییر روند بالا رفته است."})
    if snapshot.get("money_flow_score",0) >= .7:
        alerts.append({"type":"MONEY_IN","severity":"medium","text":"ورود پول سنگین شناسایی شده است."})
    if snapshot.get("money_flow_score",0) <= -.7:
        alerts.append({"type":"MONEY_OUT","severity":"medium","text":"خروج پول سنگین شناسایی شده است."})
    return alerts
