
def retail_net(buy_i_value, sell_i_value):
    return (buy_i_value or 0) - (sell_i_value or 0)

def institutional_net(buy_n_value, sell_n_value):
    return (buy_n_value or 0) - (sell_n_value or 0)

def buyer_power(buy_i_value, sell_i_value):
    s=(buy_i_value or 0)+(sell_i_value or 0)
    return (buy_i_value/s) if s else None

def heavy_flow_score(net_value, turnover):
    if not turnover or turnover <= 0:
        return 0.0
    x=net_value/turnover
    return max(-1.0,min(1.0,x*5))
