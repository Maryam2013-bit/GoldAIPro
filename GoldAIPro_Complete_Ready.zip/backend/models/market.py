
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class MarketSnapshot:
    symbol: str
    price: Optional[float]
    timestamp: datetime
    source: str
    quality: str
    delay_seconds: Optional[float] = None
    volume: Optional[float] = None
    nav: Optional[float] = None
    real_money_net: Optional[float] = None
    buyer_power: Optional[float] = None
