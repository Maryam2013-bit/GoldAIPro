
from .technical import ema, rsi, atr, trendline
from .ichimoku import ichimoku
from .scoring import score_signal

def analyze_ohlcv(high, low, close, volume=None, money_flow=None,
                  nav=None, market_price=None, xau_bias=None, usd_bias=None):
    if len(close) < 60:
        return None
    e20,e50=ema(close,20)[-1],ema(close,50)[-1]
    r=rsi(close,14); a=atr(high,low,close,14); ichi=ichimoku(high,low,close)
    factors={
      "structure": 1 if close[-1]>e50 else -1,
      "ichimoku": 1 if ichi and ichi["above_cloud"] else -1,
      "momentum": 1 if r is not None and r>=50 else -1,
      "volume": 0,
      "money_flow": 0 if money_flow is None else (1 if money_flow>0 else -1),
      "nav": 0 if nav is None or market_price is None else (1 if market_price<=nav else -1),
      "global_gold": 0 if xau_bias is None else xau_bias,
      "usd": 0 if usd_bias is None else usd_bias,
      "macro": 0
    }
    if volume and len(volume)>=20:
        avg=sum(volume[-20:])/20
        factors["volume"]=1 if volume[-1]>avg and close[-1]>=close[-2] else (-1 if volume[-1]>avg else 0)
    s=score_signal(factors); score=s["score"]
    signal="خرید پله‌ای" if score>=70 else ("فروش/کاهش ریسک" if score<=30 else "عدم معامله")
    rev=.15
    if r is not None and (r>70 or r<30): rev+=.18
    if close[-1]<e20 and close[-1]<e50: rev+=.18
    if ichi and not ichi["above_cloud"]: rev+=.16
    reasons=[("قیمت بالای میانگین ۵۰روزه است" if close[-1]>e50 else "قیمت زیر میانگین ۵۰روزه است")]
    if ichi: reasons.append("ایچیموکو صعودی است" if ichi["above_cloud"] else "ایچیموکو نزولی/ضعیف است")
    return {"signal":signal,"score":round(score,2),"reversal_probability":round(min(rev,.95)*100,1),
            "reasons":reasons,"indicators":{"ema20":e20,"ema50":e50,"rsi":r,"atr":a,
            "ichimoku":ichi,"trendline":trendline(close[-60:]),"contributions":s["contributions"]}}
