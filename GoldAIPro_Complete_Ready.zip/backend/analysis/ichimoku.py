
def ichimoku(high, low, close, tenkan=9, kijun=26, span_b=52):
    if len(close)<span_b:return None
    mid=lambda h,l:(max(h[-l:])+min(l[-l:]))/2
    ten=(max(high[-tenkan:])+min(low[-tenkan:]))/2
    kij=(max(high[-kijun:])+min(low[-kijun:]))/2
    span_a=(ten+kij)/2
    span_bv=(max(high[-span_b:])+min(low[-span_b:]))/2
    return {"tenkan":ten,"kijun":kij,"span_a":span_a,"span_b":span_bv,
            "above_cloud":close[-1]>max(span_a,span_bv)}
