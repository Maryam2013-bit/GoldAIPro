
from math import sqrt

def ema(values, period):
    if not values: return []
    k=2/(period+1); out=[values[0]]
    for v in values[1:]: out.append(v*k+out[-1]*(1-k))
    return out

def rsi(values, period=14):
    if len(values)<period+1: return None
    gains=[]; losses=[]
    for a,b in zip(values[-period-1:-1],values[-period:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/period; al=sum(losses)/period
    return 100 if al==0 else 100-(100/(1+ag/al))

def atr(high,low,close,period=14):
    if len(close)<period+1:return None
    tr=[max(high[i]-low[i],abs(high[i]-close[i-1]),abs(low[i]-close[i-1])) for i in range(1,len(close))]
    return sum(tr[-period:])/period

def trendline(values):
    if len(values)<3:return None
    n=len(values); xbar=(n-1)/2; ybar=sum(values)/n
    den=sum((i-xbar)**2 for i in range(n))
    slope=sum((i-xbar)*(y-ybar) for i,y in enumerate(values))/den if den else 0
    return {"slope":slope,"strength":min(1,abs(slope)/(sqrt(sum((y-ybar)**2 for y in values)/n)+1e-9))}
