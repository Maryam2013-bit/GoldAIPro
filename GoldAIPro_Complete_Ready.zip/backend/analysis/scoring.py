
def score_signal(factors: dict) -> dict:
    """
    Combines independently calculated factors.
    This is intentionally transparent: every contribution is returned.
    """
    weights = {
        "structure": .18,
        "ichimoku": .16,
        "momentum": .12,
        "volume": .10,
        "money_flow": .16,
        "nav": .08,
        "global_gold": .08,
        "usd": .06,
        "macro": .06,
    }
    total = 0.0
    contributions = {}
    for key, weight in weights.items():
        value = float(factors.get(key, 0.0))
        value = max(-1.0, min(1.0, value))
        c = value * weight * 100
        contributions[key] = round(c, 2)
        total += c
    return {
        "score": round(50 + total, 2),
        "contributions": contributions,
    }
