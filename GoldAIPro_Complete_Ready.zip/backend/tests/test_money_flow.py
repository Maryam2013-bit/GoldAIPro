
from services.money_flow import retail_net,buyer_power
def test_flow():
    assert retail_net(120,70)==50
    assert buyer_power(75,25)==.75
