import os
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from adapters.tsetmc_live import (
    search_symbol, closing_price, chart, client_type, client_type_history, etf_info
)
from analysis.engine import analyze_ohlcv
from services.money_flow import retail_net, buyer_power

app = FastAPI(title="Gold AI Pro API", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

DEFAULT_SYMBOL = os.getenv("AYAR_SYMBOL", "عیار")
DEFAULT_INSCODE = os.getenv("AYAR_INSCODE", "").strip()

async def resolve_inscode(symbol: str):
    if symbol == DEFAULT_SYMBOL and DEFAULT_INSCODE:
        return DEFAULT_INSCODE
    results = await search_symbol(symbol)
    if not results:
        raise HTTPException(404, f"نماد پیدا نشد: {symbol}")
    # Prefer exact normalized symbol match.
    for x in results:
        if x.get("lVal18AFC") == symbol:
            return x["insCode"]
    return results[0]["insCode"]

def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def _history_arrays(rows):
    rows = rows or []
    rows = sorted(rows, key=lambda x: int(x.get("dEven", 0)))
    high = [_num(x.get("pMax") or x.get("priceMax")) for x in rows]
    low = [_num(x.get("pMin") or x.get("priceMin")) for x in rows]
    close = [_num(x.get("pClosing") or x.get("pc") or x.get("priceClosing")) for x in rows]
    volume = [_num(x.get("qTotTran5J") or x.get("tvol") or x.get("volume")) for x in rows]
    clean = [(h,l,c,v) for h,l,c,v in zip(high,low,close,volume) if h and l and c]
    if not clean:
        return [],[],[],[]
    h,l,c,v = zip(*clean)
    return list(h), list(l), list(c), list(v)

@app.get("/api/v1/health")
async def health():
    return {"status":"ok", "time":datetime.now(timezone.utc).isoformat()}

@app.get("/api/v1/config")
async def config():
    return {
        "live_data_required": True,
        "default_symbol": DEFAULT_SYMBOL,
        "features": ["gold18","ayar","xauusd","usd","money_flow","ichimoku","reversal","alerts"],
        "refresh": {"pull_to_refresh": True, "reconnect": True}
    }

@app.get("/api/v1/snapshot")
async def snapshot(symbol: str = DEFAULT_SYMBOL):
    try:
        ins = await resolve_inscode(symbol)
        q = await closing_price(ins)
        rows = await chart(ins, "D")
        ct = await client_type(ins)
        history = await client_type_history(ins)
        if not q:
            raise HTTPException(503, "منبع قیمت داده‌ای برنگرداند")
        high, low, close, volume = _history_arrays(rows)
        if len(close) < 60:
            raise HTTPException(503, "تاریخچه کافی برای تحلیل تکنیکال دریافت نشد")

        mf = None
        bp = None
        if ct:
            bi, si = _num(ct.get("buy_I_Volume")), _num(ct.get("sell_I_Volume"))
            mf = retail_net(bi, si)
            bp = buyer_power(bi, si)

        # Daily historical retail flow as a simple recent net-flow series.
        recent_flow = []
        for x in (history or [])[-20:]:
            b, s = _num(x.get("buy_I_Value")), _num(x.get("sell_I_Value"))
            if b is not None and s is not None:
                recent_flow.append(b-s)
        flow_bias = 1 if sum(recent_flow) > 0 else (-1 if recent_flow and sum(recent_flow) < 0 else 0)

        result = analyze_ohlcv(
            high, low, close, volume=volume,
            money_flow=(1 if mf and mf > 0 else -1 if mf and mf < 0 else 0)
        )
        if not result:
            raise HTTPException(503, "تحلیل به‌دلیل ناکافی بودن داده متوقف شد")

        price = _num(q.get("pDrCotVal") or q.get("last"))
        closing = _num(q.get("pClosing") or q.get("pc"))
        previous = _num(q.get("priceYesterday") or q.get("py"))
        quality = "live"
        ts = datetime.now(timezone.utc).isoformat()

        return {
            "symbol": symbol,
            "ins_code": ins,
            "source": "TSETMC",
            "quality": quality,
            "timestamp": ts,
            "price": price,
            "closing_price": closing,
            "previous_close": previous,
            "change_percent": ((price-previous)/previous*100) if price and previous else None,
            "volume": _num(q.get("qTotTran5J") or q.get("tvol")),
            "money_flow": mf,
            "buyer_power": bp,
            "recent_flow_bias": flow_bias,
            "analysis": result,
            "warning": "سیگنال تحلیلی است و تضمین سود نیست."
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"دریافت داده زنده ناموفق بود: {type(e).__name__}")

@app.get("/api/v1/alerts")
async def alerts(symbol: str = DEFAULT_SYMBOL):
    try:
        s = await snapshot(symbol)
        a = []
        if s["analysis"]["score"] >= 70: a.append({"type":"buy","message":"امتیاز تحلیل وارد محدوده صعودی شده است."})
        if s["analysis"]["score"] <= 30: a.append({"type":"risk","message":"امتیاز تحلیل وارد محدوده ریسک نزولی شده است."})
        if s["analysis"]["reversal_probability"] >= 55: a.append({"type":"reversal","message":"احتمال تغییر روند بالاست؛ مدیریت ریسک را جدی بگیر."})
        return {"alerts":a, "timestamp":s["timestamp"]}
    except HTTPException:
        return {"alerts":[], "live_source_required":True}
