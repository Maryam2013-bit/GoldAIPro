
"""TSETMC adapter skeleton.
Endpoints are isolated here so the data source can be replaced without changing analysis.
Do not hard-code instrument codes until verified in production.
"""
import httpx

BASE="https://cdn.tsetmc.com"

async def closing_price(ins_code:str):
    url=f"{BASE}/api/ClosingPrice/GetClosingPriceInfo/{ins_code}"
    async with httpx.AsyncClient(timeout=5,headers={"User-Agent":"Mozilla/5.0"}) as c:
        r=await c.get(url); r.raise_for_status(); return r.json()

async def best_limits(ins_code:str):
    url=f"{BASE}/api/BestLimits/{ins_code}"
    async with httpx.AsyncClient(timeout=5,headers={"User-Agent":"Mozilla/5.0"}) as c:
        r=await c.get(url); r.raise_for_status(); return r.json()

async def client_type(ins_code:str):
    url=f"{BASE}/api/ClientType/GetClientType/{ins_code}/1/0"
    async with httpx.AsyncClient(timeout=5,headers={"User-Agent":"Mozilla/5.0"}) as c:
        r=await c.get(url); r.raise_for_status(); return r.json()

async def etf_info(ins_code:str):
    url=f"{BASE}/api/Fund/GetETFByInsCode/{ins_code}"
    async with httpx.AsyncClient(timeout=5,headers={"User-Agent":"Mozilla/5.0"}) as c:
        r=await c.get(url); r.raise_for_status(); return r.json()
