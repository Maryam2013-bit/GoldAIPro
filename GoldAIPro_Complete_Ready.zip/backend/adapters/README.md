
# منابع داده

برای هر منبع واقعی یک Adapter مستقل اضافه می‌شود.
اصل مهم: هیچ Adapter نباید داده ساختگی را به‌عنوان داده زنده برگرداند.

نمونه:
- Gold18Adapter
- AyarAdapter
- XAUUSDAdapter
- USDAdapter
- MacroAdapter

هر Adapter باید timestamp، منبع، کیفیت و تأخیر داده را برگرداند.
