
from abc import ABC, abstractmethod
from backend.models.market import MarketSnapshot

class MarketDataAdapter(ABC):
    name: str

    @abstractmethod
    async def snapshot(self, symbol: str) -> MarketSnapshot:
        raise NotImplementedError
