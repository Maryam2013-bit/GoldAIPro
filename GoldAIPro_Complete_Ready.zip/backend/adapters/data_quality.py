
from datetime import datetime, timezone
def validate_timestamp(ts,max_age_seconds):
    if ts is None:return False, None
    if ts.tzinfo is None:ts=ts.replace(tzinfo=timezone.utc)
    age=(datetime.now(timezone.utc)-ts).total_seconds()
    return age<=max_age_seconds,max(0,age)
def validate_price(price): return isinstance(price,(int,float)) and price>0
def conflict(values,tolerance=.01):
    v=[float(x) for x in values if x is not None]
    return len(v)>=2 and (max(v)-min(v))/max(v)>tolerance
