
"""TGJU adapter boundary.
Use an authorized/licensed data route in production. Keep source-specific parsing here.
"""
from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass
class ExternalQuote:
    symbol:str
    price:float|None
    timestamp:datetime
    source:str="TGJU"
    quality:str="unknown"

def normalize(symbol:str, price, timestamp=None):
    return ExternalQuote(symbol=symbol,price=float(price) if price is not None else None,
        timestamp=timestamp or datetime.now(timezone.utc))
