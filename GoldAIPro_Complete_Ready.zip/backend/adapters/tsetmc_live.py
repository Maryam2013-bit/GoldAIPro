import httpx
from datetime import datetime, timezone

BASE = "https://cdn.tsetmc.com/api"
HEADERS = {"User-Agent": "Mozilla/5.0 GoldAIPro/1.0"}

async def _get(path):
    async with httpx.AsyncClient(timeout=10, headers=HEADERS) as c:
        r = await c.get(BASE + path)
        r.raise_for_status()
        return r.json()

async def search_symbol(symbol: str):
    data = await _get(f"/Instrument/GetInstrumentSearch/{symbol}")
    return data.get("instrumentSearch", [])

async def closing_price(ins_code: str):
    data = await _get(f"/ClosingPrice/GetClosingPriceInfo/{ins_code}")
    return data.get("closingPriceInfo")

async def chart(ins_code: str, resolution="D"):
    data = await _get(f"/ClosingPrice/GetChartData/{ins_code}/{resolution}")
    return data.get("chartData", [])

async def client_type(ins_code: str):
    data = await _get(f"/ClientType/GetClientType/{ins_code}/1/0")
    return data.get("clientType")

async def client_type_history(ins_code: str):
    data = await _get(f"/ClientType/GetClientTypeHistory/{ins_code}")
    return data.get("clientType", [])

async def etf_info(ins_code: str):
    data = await _get(f"/Fund/GetETFByInsCode/{ins_code}")
    return data.get("etf")
