package com.goldai.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity: ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { GoldAIApp() }
    }
}

private suspend fun fetchSnapshot(base: String): JSONObject = withContext(Dispatchers.IO) {
    val url = URL(base.trimEnd('/') + "/api/v1/snapshot?symbol=%D8%B9%DB%8C%D8%A7%D8%B1")
    val c = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 8000; readTimeout = 10000; requestMethod = "GET"
    }
    try {
        val body = c.inputStream.bufferedReader().readText()
        if (c.responseCode !in 200..299) throw Exception(body)
        JSONObject(body)
    } finally { c.disconnect() }
}

@Composable fun GoldAIApp() {
    var apiBase by remember { mutableStateOf("https://YOUR-SERVER.example.com") }
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text("🪙 Gold AI Pro", style = MaterialTheme.typography.headlineSmall) }
                item { Text("تحلیل زنده صندوق عیار", style = MaterialTheme.typography.titleMedium) }
                item {
                    OutlinedTextField(apiBase, { apiBase = it }, Modifier.fillMaxWidth(),
                        label = { Text("آدرس سرور تحلیل") }, singleLine = true)
                }
                item {
                    Button(enabled=!loading, onClick={
                        loading=true; error=null
                        scope.launch {
                            try { data=fetchSnapshot(apiBase) }
                            catch(e:Exception){ error=e.message ?: "خطای اتصال" }
                            loading=false
                        }
                    }, Modifier.fillMaxWidth()) { Text(if(loading) "در حال دریافت..." else "↻ دریافت تحلیل زنده") }
                }
                item {
                    val d=data
                    if(d==null) Text(error ?: "برای شروع، آدرس سرور را وارد و بروزرسانی کنید.")
                    else {
                        val a=d.getJSONObject("analysis")
                        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text("قیمت: "+(d.optDouble("price",0.0)).toLong().toString()+" ریال")
                            Text("سیگنال: "+a.optString("signal"))
                            Text("امتیاز: "+a.optDouble("score").toString()+"/100")
                            Text("احتمال تغییر روند: "+a.optDouble("reversal_probability").toString()+"٪")
                            Text("جریان پول حقیقی: "+d.optDouble("money_flow",0.0).toLong())
                            Text("منبع: "+d.optString("source")+" | "+d.optString("timestamp"))
                            a.optJSONArray("reasons")?.let { arr ->
                                for(i in 0 until arr.length()) Text("• "+arr.getString(i))
                            }
                        }
                    }
                }
                item { Text("⚠️ سیگنال تحلیلی است و تضمین سود نیست.", color=MaterialTheme.colorScheme.error) }
            }
        }
    }
}
